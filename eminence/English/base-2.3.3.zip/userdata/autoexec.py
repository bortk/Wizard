from xbmc import executebuiltin

print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! running autoexec now"
executebuiltin('RunScript(program.AbeksisWizard, 0, action=restore)')