#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m,url = ''):
    import urllib

    r = []

    r += [('ABC', ['http://www.ustvnow.com/?stream_code=ABC', 'https://www.arconaitv.me/abcde/'], 'http://www.lyngsat-logo.com/hires/aa/abc_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('CBS', ['http://www.ustvnow.com/?stream_code=CBS', 'https://www.arconaitv.me/ceebees/'], 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/CBS_logo.svg/512px-CBS_logo.svg.png')]

    r += [('CW', ['http://www.ustvnow.com/?stream_code=CW', 'https://www.arconaitv.me/tcw/'], 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/The_CW.svg/300px-The_CW.svg.png')]

    r += [('FOX', ['http://www.ustvnow.com/?stream_code=FOX', 'https://www.arconaitv.me/foxxy/'], 'http://www.lyngsat-logo.com/hires/ff/fox_global.png|Referer=http://www.lyngsat-logo.com')]

    r += [('NBC', ['http://www.ustvnow.com/?stream_code=NBC', 'https://www.arconaitv.me/nnnbsee/'], 'http://www.lyngsat-logo.com/hires/nn/nbc_us_east.png|Referer=http://www.lyngsat-logo.com')]

    r += [('MYTV', ['http://www.ustvnow.com/?stream_code=My9'], 'http://vignette2.wikia.nocookie.net/logopedia/images/e/eb/MyNetworkTV.png/revision/latest')]

    r += [('PBS', ['http://www.ustvnow.com/?stream_code=PBS'], 'http://www.lyngsat-logo.com/hires/pp/pbs.png|Referer=http://www.lyngsat-logo.com')]

    r += [('CTV Edmonton', ['http://www.filmon.com/channel/cfrn-ctv-edmonton'], 'http://www.lyngsat-logo.com/hires/cc/ctv.png|Referer=http://www.lyngsat-logo.com')]

    r += [('CTV Regina', ['http://www.filmon.com/channel/ckck-ctv-regina'], 'http://www.lyngsat-logo.com/hires/cc/ctv.png|Referer=http://www.lyngsat-logo.com')]

    r += [('CTV Lethbridge', ['http://www.filmon.com/channel/cfcn-5-ctv-lethbridge'], 'http://www.lyngsat-logo.com/hires/cc/ctv.png|Referer=http://www.lyngsat-logo.com')]

    r += [('CTV Yorkton', ['http://www.filmon.com/channel/cicc-ctv-yorkton'], 'http://www.lyngsat-logo.com/hires/cc/ctv.png|Referer=http://www.lyngsat-logo.com')]

    r += [('BBC One', ['http://www.filmon.com/channel/bbc-one'], 'http://www.lyngsat-logo.com/hires/bb/bbc_one.png|Referer=http://www.lyngsat-logo.com')]

    r += [('BBC One Wales', ['http://www.filmon.com/channel/bbc-1-wales'], 'http://www.lyngsat-logo.com/hires/bb/bbc_one.png|Referer=http://www.lyngsat-logo.com')]

    r += [('BBC One North Ireland', ['http://www.filmon.com/channel/bbc-1-north-ireland'], 'http://www.lyngsat-logo.com/hires/bb/bbc_one.png|Referer=http://www.lyngsat-logo.com')]

    r += [('BBC One Scotland', ['http://www.filmon.com/channel/bbc-1-scotland'], 'http://www.lyngsat-logo.com/hires/bb/bbc_one.png|Referer=http://www.lyngsat-logo.com')]

    r += [('BBC Two', ['http://www.filmon.com/channel/bbc-two'], 'http://www.lyngsat-logo.com/hires/bb/bbc_two_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('ITV', ['http://www.filmon.com/channel/itv1'], 'http://www.lyngsat-logo.com/hires/ii/itv_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Channel 4', ['http://www.filmon.com/channel/channel-4'], 'http://www.lyngsat-logo.com/hires/cc/channel4_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Channel 5', ['http://www.filmon.com/channel/channel-5'], 'http://www.lyngsat-logo.com/hires/cc/channel_5_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Dave', ['http://www.filmon.com/channel/dave'], 'http://www.lyngsat-logo.com/hires/dd/dave_uktv.png|Referer=http://www.lyngsat-logo.com')]

    r += [('BBC Three', ['http://www.filmon.com/channel/bbc-three'], 'http://www.lyngsat-logo.com/hires/bb/bbc_three.png|Referer=http://www.lyngsat-logo.com')]

    r += [('BBC Four', ['http://www.filmon.com/channel/cbeebiesbbc-four'], 'http://www.lyngsat-logo.com/hires/bb/bbc_four_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('ITV 2', ['http://www.filmon.com/channel/itv2'], 'http://www.lyngsat-logo.com/hires/ii/itv2.png|Referer=http://www.lyngsat-logo.com')]

    r += [('ITV 3', ['http://www.filmon.com/channel/itv3'], 'http://www.lyngsat-logo.com/hires/ii/itv3.png|Referer=http://www.lyngsat-logo.com')]

    r += [('ITV 4', ['http://www.filmon.com/channel/itv4'], 'http://www.lyngsat-logo.com/hires/ii/itv4.png|Referer=http://www.lyngsat-logo.com')]

    r += [('ITV +1', ['http://www.filmon.com/channel/itv-plus-1'], 'http://www.lyngsat-logo.com/hires/ii/itv_uk_plus1.png|Referer=http://www.lyngsat-logo.com')]

    r += [('E4', ['http://www.filmon.com/channel/e4'], 'http://www.lyngsat-logo.com/hires/ee/e4_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('More4', ['http://www.filmon.com/channel/more4'], 'http://www.lyngsat-logo.com/hires/cc/channel4_more4_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Quest', ['http://www.filmon.com/channel/quest'], 'http://www.lyngsat-logo.com/hires/qq/quest_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('CBS Reality', ['http://www.filmon.com/channel/cbs-reality'], 'http://www.lyngsat-logo.com/hires/cc/cbs_reality_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('CBS Reality +1', ['http://www.filmon.com/channel/cbs-reality1'], 'http://www.lyngsat-logo.com/hires/cc/cbs_reality_uk_plus1.png|Referer=http://www.lyngsat-logo.com')]

    r += [('CBS Action', ['http://www.filmon.com/channel/cbs-action'], 'http://www.lyngsat-logo.com/hires/cc/cbs_action_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('CBS Drama', ['http://www.filmon.com/channel/cbs-drama'], 'http://www.lyngsat-logo.com/hires/cc/cbs_drama_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Pick', ['http://www.filmon.com/channel/pick-tv'], 'http://www.lyngsat-logo.com/hires/pp/pick_tv_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Really', ['http://www.filmon.com/channel/really'], 'http://www.lyngsat-logo.com/hires/rr/really_uktv.png|Referer=http://www.lyngsat-logo.com')]

    r += [('5 USA', ['http://www.filmon.com/channel/5usa'], 'http://www.lyngsat-logo.com/hires/cc/channel_5_uk_usa.png|Referer=http://www.lyngsat-logo.com')]

    r += [('5 Star', ['http://www.filmon.com/channel/5-star'], 'http://www.lyngsat-logo.com/hires/cc/channel_5_uk_star.png|Referer=http://www.lyngsat-logo.com')]

    r += [('ITV Be.', ['http://www.filmon.com/channel/itvbe'], 'http://www.lyngsat-logo.com/hires/ii/itv_uk_be.png|Referer=http://www.lyngsat-logo.com')]

    r += [('ITV 2 +1', ['http://www.filmon.com/channel/itv2-plus-1'], 'http://www.lyngsat-logo.com/hires/ii/itv2_plus1.png|Referer=http://www.lyngsat-logo.com')]

    r += [('ITV 3 +1', ['http://www.filmon.com/channel/itv3-plus-1'], 'http://www.lyngsat-logo.com/hires/ii/itv3_plus1.png|Referer=http://www.lyngsat-logo.com')]

    r += [('ITV 4 +1', ['http://www.filmon.com/channel/itv4-plus-1'], 'http://www.lyngsat-logo.com/hires/ii/itv4_plus1.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Tru TV', ['http://www.filmon.com/channel/tru-tv'], 'http://www.lyngsat-logo.com/hires/tt/tru_tv_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Travel Channel', ['http://www.filmon.com/channel/travel-channel1'], 'http://www.lyngsat-logo.com/hires/tt/travel_channel_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Food Network', ['http://www.filmon.com/channel/food-network'], 'http://www.lyngsat-logo.com/hires/ff/food_network_uk.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Food Network +1', ['http://www.filmon.com/channel/food-network-plus-1'], 'http://www.lyngsat-logo.com/hires/ff/food_network_uk_plus1.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Fashion TV HD', ['http://www.dailymotion.com/video/x1kwday'], 'http://www.lyngsat-logo.com/hires/ff/fashion_tv_fr_hd.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Fashion TV', ['http://www.filmon.com/channel/fashion-tv'], 'http://www.lyngsat-logo.com/hires/ff/fashion_tv_fr.png|Referer=http://www.lyngsat-logo.com')]

    r += [('NASA TV HD', ['http://nasatv-lh.akamaihd.net/i/NASA_101@319270/master.m3u8'], 'http://www.lyngsat-logo.com/hires/nn/nasa_tv_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('NASA TV', ['http://www.filmon.com/channel/nasa-hd'], 'http://www.lyngsat-logo.com/hires/nn/nasa_tv_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Yesterday', ['http://www.filmon.com/channel/yesterday'], 'http://www.lyngsat-logo.com/hires/yy/yesterday_uktv.png|Referer=http://www.lyngsat-logo.com')]

    r += [('A&E', ['https://www.arconaitv.me/ae/'], 'http://www.lyngsat-logo.com/hires/aa/ae_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('AMC', ['https://www.arconaitv.me/am/'], 'http://www.lyngsat-logo.com/hires/aa/amc_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Animal Planet', ['https://www.arconaitv.me/ap/'], 'http://www.lyngsat-logo.com/hires/aa/animal_planet_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Bravo', ['https://www.arconaitv.me/braveotv/'], 'http://www.lyngsat-logo.com/hires/bb/bravo_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Comedy Central', ['https://www.arconaitv.me/cc/'], 'http://www.lyngsat-logo.com/hires/cc/comedy_central_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Discovery Channel', ['https://www.arconaitv.me/disco/'], 'http://www.lyngsat-logo.com/hires/dd/discovery_us_east.png|Referer=http://www.lyngsat-logo.com')]

    r += [('FX', ['https://www.arconaitv.me/fx/'], 'http://www.lyngsat-logo.com/hires/ff/fx_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Lifetime', ['https://www.arconaitv.me/lt/'], 'http://www.lyngsat-logo.com/hires/ll/lifetime_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('National Geograpic', ['https://www.arconaitv.me/ng/'], 'http://www.lyngsat-logo.com/hires/nn/nat_geo_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Spike', ['https://www.arconaitv.me/pointytv/'], 'http://www.lyngsat-logo.com/hires/ss/spike_tv_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('Syfy', ['https://www.arconaitv.me/sify/'], 'http://www.lyngsat-logo.com/hires/ss/syfy_us_global.png|Referer=http://www.lyngsat-logo.com')]

    r += [('TBS', ['https://www.arconaitv.me/teabees/'], 'http://www.lyngsat-logo.com/hires/tt/tbs_east.png|Referer=http://www.lyngsat-logo.com')]

    r += [('TNT', ['https://www.arconaitv.me/teentee/'], 'http://www.lyngsat-logo.com/hires/tt/tnt_us.png|Referer=http://www.lyngsat-logo.com')]

    r += [('USA', ['https://www.arconaitv.me/usan/'], 'http://www.lyngsat-logo.com/hires/uu/usa_network_east.png|Referer=http://www.lyngsat-logo.com')]

    r = [(i[0], urllib.quote_plus(str(i[1])), i[2]) for i in r]
    return r
