#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m,url = 'http://alphareborn.offshorepastebin.com/arb/home.xml'):
    from resources.lib.modules import control
    if not control.infoLabel('Container.PluginName') == 'plugin.video.phstreams': return
    from resources.lib.indexers import phstreams
    phstreams.indexer().get(url)