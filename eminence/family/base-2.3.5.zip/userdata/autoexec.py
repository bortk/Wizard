from xbmc import executebuiltin

print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! running autoexec now"
executebuiltin('RunScript(program.AbeksisWizard, 0, action=restore)')
# [BUBBLESCODE]
import xbmc
if xbmc.getCondVisibility("System.HasAddon(plugin.video.bubbles)") == 1:
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.bubbles/?action=launch)")
# [/BUBBLESCODE]