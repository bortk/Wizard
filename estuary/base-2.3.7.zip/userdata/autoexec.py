# [BUBBLESCODE]
import xbmc
if xbmc.getCondVisibility("System.HasAddon(plugin.video.bubbles)") == 1:
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.bubbles/?action=launch)")
# [/BUBBLESCODE]