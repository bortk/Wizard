#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m,url = '%5B%27http%3A%2F%2Fwww.dailymotion.com%2Fvideo%2Fx1kwday%27%5D'):
    from resources.lib.modules import client
    from resources.lib.modules import proxy
    import re,urllib,urlparse,json

    streams = eval(urllib.unquote_plus(url))

    for stream in streams:
        try:
            if 'arconaitv.me' in stream:
                r = proxy.request(stream, 'm3u8')
                u = re.findall('src="(.+m3u8.+?)"', r)[-1].strip().split('"')[0]
                try: u = uparse.parse_qs(uparse.uparse(u).query)['u'][0]
                except: pass
                try: u = uparse.parse_qs(uparse.uparse(u).query)['q'][0]
                except: pass
                u += '|User-Agent=iPhone'
                return u

            elif 'ustvnow.com' in stream:
                t = 'z1w1wxfvamjlgbrvjvtms5n8effo'
                r = 'http://m-api.ustvnow.com/gtv/1/live/playingnow?token=%s' % t[::-1]
                r = json.loads(client.request(r))
                s = urlparse.parse_qs(urlparse.urlparse(stream).query)['stream_code'][0]
                s = [i['scode'] for i in r['results'] if i['stream_code'] == s][0]
                k = (r['globalparams']['passkey']).replace('key=', '')
                m = 'http://m-api.ustvnow.com/stream/1/live/view?token=%s&key=%s&scode=%s' % (t[::-1], k, s)
                m = json.loads(client.request(m))['stream']
                if not '.m3u8' in m: raise Exception() 
                u = client.request(m)
                u = re.findall('=\s*\d{3}x\d*\n(.+)', u)[-1]
                u = urlparse.urljoin(m, u)
                return u

            else:
                return stream
        except:
            pass
